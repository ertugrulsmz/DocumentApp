package com.work.document.web.dto;

import com.work.document.service.UpdateDocumentRequest;
import com.work.document.web.util.LocalDateConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;

public class UpdateDocumentRequestDto {

    public static final Logger LOGGER = LoggerFactory.getLogger(UpdateDocumentRequestDto.class);

    private String customerName;
    private String projectName;
    private Integer size;
    private Integer annualUnit;
    private String deadline;
    private String responsible;
    private String description;

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Integer getAnnualUnit() {
        return annualUnit;
    }

    public void setAnnualUnit(Integer annualUnit) {
        this.annualUnit = annualUnit;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    public String getResponsible() {
        return responsible;
    }

    public void setResponsible(String responsible) {
        this.responsible = responsible;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public UpdateDocumentRequest    convertToServiceRequest() {
        UpdateDocumentRequest updateDocumentRequest = new UpdateDocumentRequest();
        BeanUtils.copyProperties(this, updateDocumentRequest);
        LocalDateConverter.mapToLocalDate(this.getDeadline()).ifPresent(updateDocumentRequest::setDeadline);
        return updateDocumentRequest;
    }
}
