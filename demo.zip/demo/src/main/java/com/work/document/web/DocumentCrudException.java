package com.work.document.web;

public class DocumentCrudException extends RuntimeException {
    public DocumentCrudException(String message) {
        super(message);
    }
}
