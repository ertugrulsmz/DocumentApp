package com.work.document.service;

public class DocumentCrudException extends RuntimeException {
    public DocumentCrudException(String message) {
        super(message);
    }
}
