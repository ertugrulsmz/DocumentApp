package com.work.document.web.util;

import com.work.document.web.dto.UpdateDocumentRequestDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class LocalDateConverter {

    public static final Logger LOGGER = LoggerFactory.getLogger(LocalDateConverter.class);

    public static Optional<LocalDate> mapToLocalDate(String request) {
        try{
            List<Integer> numbers = Arrays.stream(request.trim().split("-")).map(Integer::parseInt)
                    .collect(Collectors.toList());

            if (numbers.size() < 3){
                LOGGER.warn("Request input {} is not converted to localDate as missing numbers exists", request);
                return Optional.empty();
            }

            return Optional.of(LocalDate.of(numbers.get(0), numbers.get(1), numbers.get(2)));
        } catch (Exception e){
            LOGGER.warn("Request input {} is not converted to localDate", request);
            return Optional.empty();
        }

    }
}
