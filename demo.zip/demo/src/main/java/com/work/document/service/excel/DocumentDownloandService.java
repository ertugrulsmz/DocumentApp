package com.work.document.service.excel;

import com.work.document.service.DocumentService;
import com.work.document.service.DocumentResponse;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DocumentDownloandService {

    private final DocumentExcelGenerator documentExcelGenerator;
    private final DocumentService documentService;

    public DocumentDownloandService(DocumentExcelGenerator documentExcelGenerator, DocumentService documentService) {
        this.documentExcelGenerator = documentExcelGenerator;
        this.documentService = documentService;
    }

    public byte[] getUserXlsxData(int page, int size) {
        List<DocumentResponse> documentEntities = documentService.findPaginated(page, size);
        return getDocumentBytes(documentEntities);
    }

    public byte[] getAllUserXlsxData() {
        List<DocumentResponse> documentEntities = documentService.findAll();
        return getDocumentBytes(documentEntities);
    }



    private byte[] getDocumentBytes(List<DocumentResponse> documentEntities) {
        List<DocumentExcelEntity> documentExcelEntities = documentEntities.stream()
                .map(this::convertToExcelEntity).collect(Collectors.toList());
        String[] columnTitles = {"customerName", "projectName", "size", "annualUnit", "date", "responsible", "description"};
        try {
            return documentExcelGenerator.getUserXlsxData(documentExcelEntities, columnTitles);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public DocumentExcelEntity convertToExcelEntity(DocumentResponse document){
        DocumentExcelEntity documentExcelEntity = new DocumentExcelEntity();
        documentExcelEntity.setDate(document.getDeadline());
        documentExcelEntity.setSize(document.getSize());
        documentExcelEntity.setDescription(document.getDescription());
        documentExcelEntity.setResponsible(document.getResponsible());
        documentExcelEntity.setCustomerName(document.getCustomerName());
        documentExcelEntity.setAnnualUnit(document.getAnnualUnit());
        documentExcelEntity.setProjectName(document.getProjectName());
        return documentExcelEntity;
    }
}
