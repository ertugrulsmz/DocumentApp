package com.work.document.service.excel;

import com.work.document.persistence.DocumentEntity;
import com.work.document.persistence.DocumentRepository;
import com.work.document.service.DocumentService;
import com.work.document.service.DocumentResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class DocumentDownloandService {

    private final DocumentExcelGenerator documentExcelGenerator;
    private final DocumentService documentService;

    private final DocumentRepository documentRepository;

    public DocumentDownloandService(DocumentExcelGenerator documentExcelGenerator, DocumentService documentService, DocumentRepository documentRepository) {
        this.documentExcelGenerator = documentExcelGenerator;
        this.documentService = documentService;
        this.documentRepository = documentRepository;
    }

    public byte[] getUserXlsxData(int page, int size) {
        List<DocumentResponse> documentEntities = documentService.findPaginated(page, size);
        return getDocumentBytes(documentEntities);
    }

    public byte[] getAllUserXlsxData() {
        List<DocumentResponse> documentEntities = documentService.findAll();
        return getDocumentBytes(documentEntities);
    }

    public void uploadExcelFileToDb(MultipartFile file, boolean firstRowTitleExist) {
        try {
            List<DocumentExcelEntity> documentExcelEntities = documentExcelGenerator.readToEntity(file.getInputStream(),DocumentExcelEntity.class, firstRowTitleExist);
            List<DocumentEntity> entities = documentExcelEntities.stream().map(this::convertToDbEntity).collect(Collectors.toList());
            documentRepository.saveAllAndFlush(entities);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }



    private byte[] getDocumentBytes(List<DocumentResponse> documentEntities) {
        List<DocumentExcelEntity> documentExcelEntities = documentEntities.stream()
                .map(this::convertToExcelEntity).collect(Collectors.toList());
        String[] columnTitles = {"customerName", "projectName", "size", "annualUnit", "deadline", "responsible", "description"};
        try {
            return documentExcelGenerator.getUserXlsxData(documentExcelEntities, columnTitles);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private DocumentExcelEntity convertToExcelEntity(DocumentResponse document){
        DocumentExcelEntity documentExcelEntity = new DocumentExcelEntity();
        documentExcelEntity.setDeadline(document.getDeadline());
        documentExcelEntity.setSize(document.getSize());
        documentExcelEntity.setDescription(document.getDescription());
        documentExcelEntity.setResponsible(document.getResponsible());
        documentExcelEntity.setCustomerName(document.getCustomerName());
        documentExcelEntity.setAnnualUnit(document.getAnnualUnit());
        documentExcelEntity.setProjectName(document.getProjectName());
        return documentExcelEntity;
    }

    private DocumentEntity convertToDbEntity(DocumentExcelEntity excelEntity) {
        DocumentEntity documentEntity = new DocumentEntity();
        documentEntity.setPublicId(UUID.randomUUID().toString());
        documentEntity.setDeadline(excelEntity.getDeadline());
        documentEntity.setDescription(excelEntity.getDescription());
        documentEntity.setResponsible(excelEntity.getResponsible());
        documentEntity.setCustomerName(excelEntity.getCustomerName());
        documentEntity.setProjectName(excelEntity.getProjectName());
        documentEntity.setAnnualUnit(excelEntity.getAnnualUnit());
        documentEntity.setSize(excelEntity.getSize());
        return documentEntity;
    }
}
