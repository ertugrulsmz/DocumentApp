package com.work.document.web;

import com.work.document.service.DocumentService;
import com.work.document.web.dto.CreateDocumentRequest;
import com.work.document.web.dto.DocumentResponse;
import com.work.document.web.dto.UpdateDocumentRequest;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/v1/document")
public class DocumentController {

    private final DocumentService documentService;

    public DocumentController(DocumentService documentService) {
        this.documentService = documentService;
    }

    @PostMapping
    public DocumentResponse createDocument(@RequestBody CreateDocumentRequest createDocumentRequest) {
        return documentService.create(createDocumentRequest);
    }

    @GetMapping("/{id}")
    public DocumentResponse getDocument(@PathVariable String id) {
        return documentService.findByPublicId(id);
    }

    @PatchMapping("/{id}")
    public DocumentResponse updateDocument(@PathVariable String id, @RequestBody UpdateDocumentRequest request) {
        return documentService.updateDocument(id, request);
    }

    @GetMapping(params = { "page", "size" })
    public List<DocumentResponse> listPaginated(@RequestParam("page") int page,
                                                @RequestParam("size") int size) {
        return documentService.findPaginated(page, size);
    }



}
