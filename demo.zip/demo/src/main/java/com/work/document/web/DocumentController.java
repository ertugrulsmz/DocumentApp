package com.work.document.web;

import com.work.document.service.DocumentService;
import com.work.document.service.CreateDocumentRequest;
import com.work.document.service.DocumentResponse;
import com.work.document.service.UpdateDocumentRequest;
import com.work.document.web.dto.CreateDocumentRequestDto;
import com.work.document.web.dto.UpdateDocumentRequestDto;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/v1/document")
public class DocumentController {

    private final DocumentService documentService;

    public DocumentController(DocumentService documentService) {
        this.documentService = documentService;
    }

    @PostMapping
    public DocumentResponse createDocument(@RequestBody CreateDocumentRequestDto createDocumentRequest) {

        return documentService.create(createDocumentRequest.convertToServiceRequest());
    }

    @GetMapping("/{id}")
    public DocumentResponse getDocument(@PathVariable String id) {
        return documentService.findByPublicId(id);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable String id) {
        documentService.deleteByPublicId(id);
    }



    @PatchMapping("/{id}")
    public DocumentResponse updateDocument(@PathVariable String id, @RequestBody UpdateDocumentRequestDto request) {
        return documentService.updateDocument(id, request.convertToServiceRequest());
    }

    @GetMapping()
    public List<DocumentResponse> list(@RequestParam(name="page", defaultValue = "0", required = false) String page,
                                       @RequestParam(name="size", defaultValue = "0", required = false) String  size) {

        if (page.equals("0") && size.equals("0")){
            return documentService.findAll();
        }

        return documentService.findPaginated(Integer.parseInt(page), Integer.parseInt(size));
    }



}
