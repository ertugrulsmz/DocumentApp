package com.work.document.persistence;

import javax.persistence.*;
import java.time.LocalDate;

@Entity(name = "document")
public class DocumentEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "public_id")
    private String publicId;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "project_name")
    private String projectName;

    @Column(name = "size")
    private int size;

    @Column(name = "annual_unit")
    private int annualUnit;

    @Column(name = "deadline")
    private LocalDate deadline;

    @Column(name = "responsible")
    private String responsible;

    @Column(name = "description")
    private String description;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getAnnualUnit() {
        return annualUnit;
    }

    public void setAnnualUnit(int annualUnit) {
        this.annualUnit = annualUnit;
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDate deadline) {
        this.deadline = deadline;
    }

    public String getResponsible() {
        return responsible;
    }

    public void setResponsible(String responsible) {
        this.responsible = responsible;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPublicId() {
        return publicId;
    }

    public void setPublicId(String publicId) {
        this.publicId = publicId;
    }
}
