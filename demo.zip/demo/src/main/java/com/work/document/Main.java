package com.work.document;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.work.document.service.UpdateDocumentRequest;

import java.time.LocalDate;
import java.time.Month;

public class Main {

        public static void main(String[] args) throws JsonProcessingException {
            UpdateDocumentRequest recording = new UpdateDocumentRequest();
            recording.setDeadline(LocalDate.of(1964, Month.FEBRUARY, 3));

            ObjectMapper mapper = new ObjectMapper();
            try {
                String json = mapper.writeValueAsString(recording);
                System.out.println("JSON = " + json);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }

            String resp = "{\"customerName\":null,\"projectName\":null,\"size\":null,\"annualUnit\":null,\"deadline\":\"1964-02-03\",\"responsible\":null,\"description\":null}";
            UpdateDocumentRequest updateDocumentRequest = mapper.readValue(resp, UpdateDocumentRequest.class);
            System.out.println(updateDocumentRequest);
        }

}
