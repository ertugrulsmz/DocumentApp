package com.work.document.service.excel;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class DocumentExcelGenerator {

    private final XlsxFileWriter xlsxWriter;
    private static final Logger logger = LoggerFactory.getLogger(DocumentExcelGenerator.class);

    public DocumentExcelGenerator(XlsxFileWriter xlsxWriter) {
        this.xlsxWriter = xlsxWriter;
    }

    public <T> byte[] getUserXlsxData(List<T> documentEntities, String[] columnTitles) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (bos; Workbook workbook = new XSSFWorkbook()) {
            xlsxWriter.write(documentEntities, bos, columnTitles, workbook);
        } catch (Exception e) {
            logger.error("Generating users xls file failed", e);
        }
        return bos.toByteArray();
    }
}
