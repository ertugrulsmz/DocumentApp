package com.work.document.service.excel;

import com.work.document.web.util.LocalDateConverter;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class DocumentExcelGenerator {

    private final XlsxFileWriter xlsxWriter;
    private static final Logger logger = LoggerFactory.getLogger(DocumentExcelGenerator.class);

    public DocumentExcelGenerator(XlsxFileWriter xlsxWriter) {
        this.xlsxWriter = xlsxWriter;
    }

    public <T> List<T> readToEntity(InputStream inputStream1, Class<T> clazz, boolean firstRowTitle) throws IOException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        InputStream inputStream = inputStream1;
        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
        XSSFSheet sheet = workbook.getSheetAt(0);
        List<T> list = new ArrayList<>();

        boolean firstRow = firstRowTitle;
        for (Row row : sheet) {
            if (firstRow) {
                firstRow = false;
                continue;
            }

            T documentEntity = clazz.getDeclaredConstructor().newInstance();
            list.add(documentEntity);

            int columnCounter = 0;
            for (Cell cell : row) {

                Field declaredField = documentEntity.getClass().getDeclaredFields()[columnCounter];
                declaredField.setAccessible(true);
                String valueOfTheCell = getValueOfTheCell(cell);
                if (declaredField.getType().equals(String.class)) {
                    declaredField.set(documentEntity, valueOfTheCell);
                }
                else if (declaredField.getType().equals(Integer.class)){
                    if (valueOfTheCell.equals("")){
                        declaredField.set(documentEntity, 0);
                    } else {
                        double value = Double.parseDouble(valueOfTheCell);
                        declaredField.set(documentEntity, (int)value);
                    }
                }
                else if (declaredField.getType().equals(LocalDate.class)){

                    Optional<LocalDate> value = LocalDateConverter.mapToLocalDate(getValueOfTheCell(cell));
                    if (value.isPresent()) {
                        declaredField.set(documentEntity, value.get());
                    }
                }
                else {
                    logger.warn("Unknown type {}", cell.getCellType());
                }

                columnCounter++;
            }
        }
        return list;
    }

    private String getValueOfTheCell(Cell cell) {
        switch (cell.getCellType()){
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                return String.valueOf(cell.getNumericCellValue());
            case BLANK:
                return "";
        }
        logger.warn("Non matched column please check {}", cell.getCellType());
        return "";
    }

    public <T> byte[] getUserXlsxData(List<T> documentEntities, String[] columnTitles) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (bos; Workbook workbook = new XSSFWorkbook()) {
            xlsxWriter.write(documentEntities, bos, columnTitles, workbook);
        } catch (Exception e) {
            logger.error("Generating users xls file failed", e);
        }
        return bos.toByteArray();
    }
}
