package com.work.document.service.excel;

import java.lang.annotation.*;

public class ExcelAnnotation {
    @Documented
    @Target(ElementType.TYPE)
    @Retention(RetentionPolicy.RUNTIME)
    public @interface XlsxSheet {
        String value();
    }
    @Documented
    @Target(ElementType.FIELD)
    @Retention(RetentionPolicy.RUNTIME)
    public @interface XlsxSingleField {
        int columnIndex();
    }
    @Documented
    @Target(ElementType.FIELD)
    @Retention(RetentionPolicy.RUNTIME)
    public @interface XlsxCompositeField {
        int from();
        int to();
    }
}
