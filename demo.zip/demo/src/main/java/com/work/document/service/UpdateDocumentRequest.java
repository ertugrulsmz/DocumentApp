package com.work.document.service;

import java.time.LocalDate;

public class UpdateDocumentRequest {
    private String customerName;
    private String projectName;
    private Integer size;
    private Integer annualUnit;
    private LocalDate deadline;
    private String responsible;
    private String description;

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Integer getAnnualUnit() {
        return annualUnit;
    }

    public void setAnnualUnit(Integer annualUnit) {
        this.annualUnit = annualUnit;
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDate deadline) {
        this.deadline = deadline;
    }

    public String getResponsible() {
        return responsible;
    }

    public void setResponsible(String responsible) {
        this.responsible = responsible;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


}