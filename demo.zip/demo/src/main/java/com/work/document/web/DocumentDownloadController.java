package com.work.document.web;

import com.work.document.persistence.DocumentRepository;
import com.work.document.service.excel.DocumentDownloandService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

@RestController
@RequestMapping("/v1/document")
public class DocumentDownloadController {

    private final DocumentDownloandService documentDownloandService;

    private final DocumentRepository documentRepository;

    public DocumentDownloadController(DocumentDownloandService documentDownloandService, DocumentRepository documentRepository) {
        this.documentDownloandService = documentDownloandService;
        this.documentRepository = documentRepository;
    }


    @GetMapping(value = "/download-excel")
    public ResponseEntity<?> downloadUsersExcel(@RequestParam(name="page", defaultValue = "0", required = false) String page,
                                             @RequestParam(name="size", defaultValue = "0", required = false) String  size) {


        try {
            byte[] data;
            if (size.equals("0")){
                data = documentDownloandService.getAllUserXlsxData();
            }
            else{
              data = documentDownloandService.getUserXlsxData(Integer.parseInt(page), Integer.parseInt(size));
            }
            if (data.length == 0){
                return new ResponseEntity<>(data, new HttpHeaders() , HttpStatus.OK);
            }

            HttpHeaders header = new HttpHeaders();
            header.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8"));
            header.set(HttpHeaders.CONTENT_DISPOSITION, "inline; filename= document.xlsx");
            header.setContentLength(data.length);
            return new ResponseEntity<>(data, header, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/upload-excel")
    public void uploadFile(
            @RequestParam("file") MultipartFile file) throws IOException, InvocationTargetException, InstantiationException, IllegalAccessException, NoSuchMethodException {
        documentDownloandService.uploadExcelFileToDb(file, true);
    }

}
