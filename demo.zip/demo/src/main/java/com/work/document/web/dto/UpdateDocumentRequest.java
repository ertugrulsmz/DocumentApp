package com.work.document.web.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class UpdateDocumentRequest {
    private String customerName;
    private String projectName;
    private Integer size;
    private Integer annualUnit;
    private LocalDate date;
    private String responsible;
    private String description;

}