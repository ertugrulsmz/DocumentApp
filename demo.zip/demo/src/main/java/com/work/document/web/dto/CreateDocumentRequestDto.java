package com.work.document.web.dto;

import com.work.document.service.CreateDocumentRequest;
import com.work.document.web.util.LocalDateConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class CreateDocumentRequestDto {

    public static final Logger LOGGER = LoggerFactory.getLogger(CreateDocumentRequestDto.class);

    private String publicId;
    private String customerName;
    private String projectName;
    private int size;
    private int annualUnit;

    private String deadline;
    private String responsible;
    private String description;

    public String getPublicId() {
        return publicId;
    }

    public void setPublicId(String publicId) {
        this.publicId = publicId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getAnnualUnit() {
        return annualUnit;
    }

    public void setAnnualUnit(int annualUnit) {
        this.annualUnit = annualUnit;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    public String getResponsible() {
        return responsible;
    }

    public void setResponsible(String responsible) {
        this.responsible = responsible;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public CreateDocumentRequest convertToServiceRequest() {
        CreateDocumentRequest createDocumentRequest = new CreateDocumentRequest();
        BeanUtils.copyProperties(this, createDocumentRequest);
        LocalDateConverter.mapToLocalDate(this.getDeadline()).ifPresent(createDocumentRequest::setDeadline);
        return createDocumentRequest;
    }
}
