package com.work.document.web.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class DocumentResponse {

    private String publicId;
    private String customerName;
    private String projectName;
    private int size;
    private int annualUnit;
    private LocalDate date;
    private String responsible;
    private String description;

}
