package com.work.document.service.excel;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Setter
@ExcelAnnotation.XlsxSheet(value = "Document")
public class DocumentExcelEntity {

    @ExcelAnnotation.XlsxSingleField(columnIndex = 0)
    private String customerName;
    @ExcelAnnotation.XlsxSingleField(columnIndex = 1)
    private String projectName;
    @ExcelAnnotation.XlsxSingleField(columnIndex = 2)
    private Integer size;
    @ExcelAnnotation.XlsxSingleField(columnIndex = 3)
    private Integer annualUnit;
    @ExcelAnnotation.XlsxSingleField(columnIndex = 4)
    private LocalDate deadline;
    @ExcelAnnotation.XlsxSingleField(columnIndex = 5)
    private String responsible;

    @ExcelAnnotation.XlsxSingleField(columnIndex = 6)
    private String description;

}
