package com.work.document.service;

import com.work.document.persistence.DocumentEntity;
import com.work.document.persistence.DocumentRepository;
import com.work.document.web.DocumentCrudException;
import com.work.document.web.dto.CreateDocumentRequest;
import com.work.document.web.dto.DocumentResponse;
import com.work.document.web.dto.UpdateDocumentRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DocumentService {

    private final DocumentRepository documentRepository;

    public DocumentService(DocumentRepository documentRepository) {
        this.documentRepository = documentRepository;
    }

    public DocumentResponse create(CreateDocumentRequest createDocumentRequest) {
        DocumentEntity documentEntity = mapToEntity(createDocumentRequest);
        DocumentEntity entity = documentRepository.save(documentEntity);
        return mapToDocumentResponse(entity);

    }

    private static DocumentEntity mapToEntity(CreateDocumentRequest createDocumentRequest) {
        DocumentEntity documentEntity = new DocumentEntity();
        documentEntity.setAnnualUnit(createDocumentRequest.getAnnualUnit());
        documentEntity.setDate(createDocumentRequest.getDate());
        documentEntity.setDescription(createDocumentRequest.getDescription());
        documentEntity.setSize(createDocumentRequest.getSize());
        documentEntity.setCustomerName(createDocumentRequest.getCustomerName());
        documentEntity.setProjectName(createDocumentRequest.getProjectName());
        documentEntity.setResponsible(createDocumentRequest.getResponsible());
        return documentEntity;
    }

    private static DocumentResponse mapToDocumentResponse(DocumentEntity entity) {
        DocumentResponse documentResponse = new DocumentResponse();
        documentResponse.setAnnualUnit(entity.getAnnualUnit());
        documentResponse.setDate(entity.getDate());
        documentResponse.setDescription(entity.getDescription());
        documentResponse.setSize(entity.getSize());
        documentResponse.setCustomerName(entity.getCustomerName());
        documentResponse.setProjectName(entity.getProjectName());
        documentResponse.setResponsible(entity.getResponsible());
        documentResponse.setPublicId(entity.getPublicId());
        return documentResponse;
    }

    public DocumentResponse findByPublicId(String id) {
        DocumentEntity byPublicId = documentRepository.findByPublicId(id)
                .orElseThrow(() -> new DocumentCrudException("Document with id : " + id + " not found"));
        return mapToDocumentResponse(byPublicId);
    }

    public DocumentResponse updateDocument(String id, UpdateDocumentRequest request) {
        DocumentEntity byPublicId = documentRepository.findByPublicId(id)
                .orElseThrow(() -> new DocumentCrudException("Document with id : " + id + " not found"));

        if (request.getAnnualUnit() != null) {
            byPublicId.setAnnualUnit(request.getAnnualUnit());
        }
        if (request.getDate() != null) {
            byPublicId.setDate(request.getDate());
        }
        if (request.getSize() != null) {
            byPublicId.setSize(request.getSize());
        }
        if (request.getDescription() != null) {
            byPublicId.setDescription(request.getDescription());
        }
        if (request.getResponsible() != null) {
            byPublicId.setResponsible(request.getResponsible());
        }
        if (request.getCustomerName() != null) {
            byPublicId.setCustomerName(request.getCustomerName());
        }
        if (request.getProjectName() != null) {
            byPublicId.setProjectName(request.getProjectName());
        }

        documentRepository.save(byPublicId);
        return mapToDocumentResponse(byPublicId);
    }

    public List<DocumentResponse> findPaginated(int page, int size) {
        Page<DocumentEntity> resultPage = documentRepository.findAll(PageRequest.of(page, size));
        if (page > resultPage.getTotalPages()) {
            throw new IllegalStateException();
        }

        return resultPage.getContent().stream()
                .map(DocumentService::mapToDocumentResponse).collect(Collectors.toList());

    }
}
